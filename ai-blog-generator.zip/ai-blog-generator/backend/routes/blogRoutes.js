const express = require('express');
const { generateBlogPost, getBlogPosts } = require('../controllers/blogController');
const { authenticate } = require('../middleware/auth');
const { validateBlogGeneration } = require('../middleware/validation');

const router = express.Router();

router.post('/generate', authenticate, validateBlogGeneration, generateBlogPost);
router.get('/posts', authenticate, getBlogPosts);

module.exports = router;

