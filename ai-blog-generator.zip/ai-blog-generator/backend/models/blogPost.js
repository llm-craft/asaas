const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const BlogPost = sequelize.define('BlogPost', {
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    content: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    primaryKeyword: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    relatedKeywords: {
      type: DataTypes.ARRAY(DataTypes.STRING),
    },
  });

  return BlogPost;
};

