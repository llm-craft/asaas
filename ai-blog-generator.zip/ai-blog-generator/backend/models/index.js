const { Sequelize } = require('sequelize');
const UserModel = require('./user');
const BlogPostModel = require('./blogPost');

const sequelize = new Sequelize(process.env.DATABASE_URL, {
  dialect: 'postgres',
  logging: false,
});

const User = UserModel(sequelize);
const BlogPost = BlogPostModel(sequelize);

// Associations
User.hasMany(BlogPost);
BlogPost.belongsTo(User);

module.exports = {
  sequelize,
  User,
  BlogPost,
};

