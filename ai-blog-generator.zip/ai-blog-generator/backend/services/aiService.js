const { GoogleGenerativeAI } = require("@google/generative-ai");

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const model = genAI.getGenerativeModel({ model: "gemini-pro" });

exports.generateContent = async ({ primaryKeyword, relatedKeywords, title, targetAudience, tone, wordCount, format }) => {
  try {
    const prompt = `
      Write a blog post about "${title}" targeting ${targetAudience}.
      Primary keyword: ${primaryKeyword}
      Related keywords: ${relatedKeywords.join(', ')}
      Tone: ${tone}
      Word count: ${wordCount}
      Format: ${format}

      Please create a well-structured, informative, and engaging blog post that incorporates the primary and related keywords naturally. Ensure the content is SEO-friendly and provides value to the target audience.
    `;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const generatedText = response.text();

    return generatedText;
  } catch (error) {
    console.error('Error generating content:', error);
    throw new Error('Failed to generate content');
  }
};

