const cheerio = require('cheerio');

exports.optimizeForSEO = async (content, primaryKeyword, relatedKeywords) => {
  try {
    const $ = cheerio.load(content);

    // Ensure primary keyword is in the first paragraph
    const firstParagraph = $('p').first();
    if (!firstParagraph.text().toLowerCase().includes(primaryKeyword.toLowerCase())) {
      firstParagraph.prepend(`${primaryKeyword} `);
    }

    // Add primary keyword to headings if not present
    $('h1, h2, h3').each((i, elem) => {
      const heading = $(elem);
      if (!heading.text().toLowerCase().includes(primaryKeyword.toLowerCase())) {
        heading.append(` - ${primaryKeyword}`);
      }
    });

    // Add related keywords to content if not present
    relatedKeywords.forEach(keyword => {
      if (!content.toLowerCase().includes(keyword.toLowerCase())) {
        $('p').last().append(` ${keyword}.`);
      }
    });

    // Add meta description
    $('head').append(`<meta name="description" content="Learn about ${primaryKeyword} and ${relatedKeywords.join(', ')}. ${$('p').first().text().slice(0, 150)}...">`);

    // Add schema markup
    const schemaScript = `
      <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": "${$('h1').first().text()}",
        "keywords": "${[primaryKeyword, ...relatedKeywords].join(', ')}",
        "articleBody": "${$('p').text().replace(/"/g, '\\"')}"
      }
      </script>
    `;
    $('head').append(schemaScript);

    return $.html();
  } catch (error) {
    console.error('Error optimizing content for SEO:', error);
    throw new Error('Failed to optimize content for SEO');
  }
};

