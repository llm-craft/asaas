const { User } = require('../models');

exports.getUserProfile = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['password'] }
    });
    res.json(user);
  } catch (error) {
    next(error);
  }
};

exports.updateUserProfile = async (req, res, next) => {
  try {
    const { name, email } = req.body;

    const user = await User.findByPk(req.user.id);
    user.name = name;
    user.email = email;
    await user.save();

    res.json({ message: 'Profile updated successfully', user });
  } catch (error) {
    next(error);
  }
};

