const { BlogPost } = require('../models');
const { generateContent } = require('../services/aiService');
const { optimizeForSEO } = require('../services/seoService');

exports.generateBlogPost = async (req, res, next) => {
  try {
    const { primaryKeyword, relatedKeywords, title, targetAudience, tone, wordCount, format } = req.body;

    // Generate content using AI
    const generatedContent = await generateContent({
      primaryKeyword,
      relatedKeywords,
      title,
      targetAudience,
      tone,
      wordCount,
      format
    });

    // Optimize content for SEO
    const optimizedContent = await optimizeForSEO(generatedContent, primaryKeyword, relatedKeywords);

    // Save the blog post
    const blogPost = await BlogPost.create({
      userId: req.user.id,
      title,
      content: optimizedContent,
      primaryKeyword,
      relatedKeywords
    });

    res.status(201).json(blogPost);
  } catch (error) {
    next(error);
  }
};

exports.getBlogPosts = async (req, res, next) => {
  try {
    const blogPosts = await BlogPost.findAll({ where: { userId: req.user.id } });
    res.json(blogPosts);
  } catch (error) {
    next(error);
  }
};

