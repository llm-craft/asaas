const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { User } = require('../models');

exports.createCheckoutSession = async (req, res, next) => {
  try {
    const { priceId } = req.body;

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: `${process.env.FRONTEND_URL}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/payment-cancelled`,
      customer_email: req.user.email,
    });

    res.json({ sessionId: session.id });
  } catch (error) {
    next(error);
  }
};

exports.handleWebhook = async (req, res, next) => {
  const sig = req.headers['stripe-signature'];

  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;

    // Update user's subscription status
    const user = await User.findOne({ where: { email: session.customer_email } });
    if (user) {
      user.subscriptionStatus = 'active';
      user.subscriptionId = session.subscription;
      await user.save();
    }
  }

  res.json({ received: true });
};

