import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';

function DashboardPage() {
  const { user } = useAuth();
  const [blogPosts, setBlogPosts] = useState([]);
  const [formData, setFormData] = useState({
    primaryKeyword: '',
    relatedKeywords: '',
    title: '',
    targetAudience: '',
    tone: '',
    wordCount: 500,
    format: 'blog-post'
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchBlogPosts();
  }, []);

  const fetchBlogPosts = async () => {
    try {
      const response = await api.get('/blog/posts');
      setBlogPosts(response.data);
    } catch (error) {
      console.error('Error fetching blog posts:', error);
      setError('Failed to fetch blog posts');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await api.post('/blog/generate', formData);
      setBlogPosts(prevPosts => [response.data, ...prevPosts]);
      setFormData({
        primaryKeyword: '',
        relatedKeywords: '',
        title: '',
        targetAudience: '',
        tone: '',
        wordCount: 500,
        format: 'blog-post'
      });
    } catch (error) {
      console.error('Error generating blog post:', error);
      setError('Failed to generate blog post');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-6 py-8">
      <h1 className="text-3xl font-bold mb-8">Welcome, {user.name}!</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-bold mb-4">Generate New Blog Post</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="primaryKeyword" className="block mb-1">Primary Keyword</label>
              <input
                type="text"
                id="primaryKeyword"
                name="primaryKeyword"
                value={formData.primaryKeyword}
                onChange={handleInputChange}
                required
                className="w-full px-3 py-2 border rounded-md"
              />
            </div>
            <div>
              <label htmlFor="relatedKeywords" className="block mb-1">Related Keywords (comma-separated)</label>
              <input
                type="text"
                id="relatedKeywords"
                name="relatedKeywords"
                value={formData.relatedKeywords}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-md"
              />
            </div>
            <div>
              <label htmlFor="title" className="block mb-1">Blog Post Title</label>
              <input
                type="text"
                id="title"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                required
                className="w-full px-3 py-2 border rounded-md"
              />
            </div>
            <div>
              <label htmlFor="targetAudience" className="block mb-1">Target Audience</label>
              <input
                type="text"
                id="targetAudience"
                name="targetAudience"
                value={formData.targetAudience}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-md"
              />
            </div>
            <div>
              <label htmlFor="tone" className="block mb-1">Tone</label>
              <select
                id="tone"
                name="tone"
                value={formData.tone}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-md"
              >
                <option value="">Select Tone</option>
                <option value="informative">Informative</option>
                <option value="conversational">Conversational</option>
                <option value="professional">Professional</option>
                <option value="humorous">Humorous</option>
              </select>
            </div>
            <div>
              <label htmlFor="wordCount" className="block mb-1">Word Count</label>
              <input
                type="number"
                id="wordCount"
                name="wordCount"
                value={formData.wordCount}
                onChange={handleInputChange}
                min="100"
                max="5000"
                className="w-full px-3 py-2 border rounded-md"
              />
            </div>
            <div>
              <label htmlFor="format" className="block mb-1">Format</label>
              <select
                id="format"
                name="format"
                value={formData.format}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-md"
              >
                <option value="blog-post">Blog Post</option>
                <option value="article">Article</option>
                <option value="listicle">Listicle</option>
                <option value="how-to">How-To Guide</option>
              </select>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
            >
              {loading ? 'Generating...' : 'Generate Blog Post'}
            </button>
          </form>
          {error && <p className="text-red-500 mt-4">{error}</p>}
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-4">Your Blog Posts</h2>
          {blogPosts.length > 0 ? (
            <ul className="space-y-4">
              {blogPosts.map(post => (
                <li key={post.id} className="bg-white p-4 rounded-md shadow">
                  <h3 className="text-xl font-bold mb-2">{post.title}</h3>
                  <p className="text-gray-600 mb-2">Primary Keyword: {post.primaryKeyword}</p>
                  <p className="text-gray-600 mb-2">Related Keywords: {post.relatedKeywords.join(', ')}</p>
                  <button
                    onClick={() => {/* Implement view/edit functionality */}}
                    className="text-blue-500 hover:text-blue-600"
                  >
                    View/Edit
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p>No blog posts yet. Start generating!</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default DashboardPage;

