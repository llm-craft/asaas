import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';

function PricingPage() {
  const { user } = useAuth();

  const handleSubscribe = async (priceId) => {
    try {
      const response = await api.post('/payment/create-checkout-session', { priceId });
      window.location.href = response.data.url;
    } catch (error) {
      console.error('Error creating checkout session:', error);
    }
  };

  return (
    <div className="bg-gray-100 min-h-screen py-12">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl font-bold text-center mb-8">Choose Your Plan</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white rounded-lg shadow-md p-8">
            <h2 className="text-2xl font-bold mb-4">Free</h2>
            <p className="text-4xl font-bold mb-6">$0<span className="text-lg font-normal">/month</span></p>
            <ul className="mb-8">
              <li className="mb-2">✅ 5 blog posts per month</li>
              <li className="mb-2">✅ Basic SEO optimization</li>
              <li className="mb-2">✅ Limited keyword research</li>
            </ul>
            <button
              onClick={() => handleSubscribe('price_free')}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
              disabled={user && user.subscriptionStatus === 'free'}
            >
              {user && user.subscriptionStatus === 'free' ? 'Current Plan' : 'Get Started'}
            </button>
          </div>
          <div className="bg-white rounded-lg shadow-md p-8 border-4 border-blue-500">
            <h2 className="text-2xl font-bold mb-4">Pro</h2>
            <p className="text-4xl font-bold mb-6">$29<span className="text-lg font-normal">/month</span></p>
            <ul className="mb-8">
              <li className="mb-2">✅ 50 blog posts per month</li>
              <li className="mb-2">✅ Advanced SEO optimization</li>
              <li className="mb-2">✅ Full keyword research</li>
              <li className="mb-2">✅ Custom formatting options</li>
            </ul>
            <button
              onClick={() => handleSubscribe('price_pro')}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
              disabled={user && user.subscriptionStatus === 'active'}
            >
              {user && user.subscriptionStatus === 'active' ? 'Current Plan' : 'Subscribe'}
            </button>
          </div>
          <div className="bg-white rounded-lg shadow-md p-8">
            <h2 className="text-2xl font-bold mb-4">Enterprise</h2>
            <p className="text-4xl font-bold mb-6">Custom</p>
            <ul className="mb-8">
              <li className="mb-2">✅ Unlimited blog posts</li>
              <li className="mb-2">✅ Premium SEO optimization</li>
              <li className="mb-2">✅ Advanced analytics</li>
              <li className="mb-2">✅ Dedicated support</li>
            </ul>
            <button
              onClick={() => {/* Implement contact sales functionality */}}
              className="w-full bg-gray-800 hover:bg-gray-900 text-white font-bold py-2 px-4 rounded"
            >
              Contact Sales
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PricingPage;

