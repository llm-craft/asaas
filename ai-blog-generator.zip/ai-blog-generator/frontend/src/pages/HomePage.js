import React from 'react';
import { Link } from 'react-router-dom';

function HomePage() {
  return (
    <div className="bg-gray-100 min-h-screen">
      <div className="container mx-auto px-6 py-16">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-2">Effortlessly Generate SEO-Optimized Blog Posts with AI</h1>
          <p className="text-xl mb-8">Create high-quality content in minutes, not hours.</p>
          <Link to="/register" className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg text-lg">
            Get Started Free
          </Link>
        </div>

        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-8 text-center">Key Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-4">AI-Powered Content Generation</h3>
              <p>Leverage cutting-edge AI technology to create unique and engaging blog posts.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-4">SEO Optimization</h3>
              <p>Automatically optimize your content for search engines to improve your rankings.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-bold mb-4">User-Friendly Interface</h3>
              <p>Intuitive design makes it easy to generate and manage your blog posts.</p>
            </div>
          </div>
        </div>

        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold mb-8">Ready to revolutionize your content creation?</h2>
          <Link to="/register" className="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg text-lg">
            Start Your Free Trial
          </Link>
        </div>
      </div>
    </div>
  );
}

export default HomePage;

