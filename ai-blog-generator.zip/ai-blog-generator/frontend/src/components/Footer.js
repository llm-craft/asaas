import React from 'react';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-6">
        <div className="flex flex-wrap justify-between items-center">
          <div className="w-full md:w-1/3 text-center md:text-left">
            <h3 className="text-lg font-bold mb-2">AI Blog Generator</h3>
            <p className="text-sm">Effortlessly create SEO-optimized content</p>
          </div>
          <div className="w-full md:w-1/3 text-center mt-4 md:mt-0">
            <ul className="inline-flex flex-wrap justify-center">
              <li><Link to="/pricing" className="hover:text-gray-300 mx-2">Pricing</Link></li>
              <li><Link to="/terms" className="hover:text-gray-300 mx-2">Terms of Service</Link></li>
              <li><Link to="/privacy" className="hover:text-gray-300 mx-2">Privacy Policy</Link></li>
            </ul>
          </div>
          <div className="w-full md:w-1/3 text-center md:text-right mt-4 md:mt-0">
            <p>&copy; 2023 AI Blog Generator. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;

